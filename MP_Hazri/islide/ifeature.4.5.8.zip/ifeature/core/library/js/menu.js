jQuery(document).ready(function($){
	$("ul").parent("li").addClass("parent"); 
});
